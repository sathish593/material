package com.uhg;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;


public class WrongDestination extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
    String userAgent = request.getHeader("User-Agent");
    if ((userAgent != null) &&
        (userAgent.contains("MSIE"))) {
      response.sendRedirect("http://www.mozilla.com/");
    } else {
      response.sendRedirect("http://www.microsoft.com/");
    }
  }
}
