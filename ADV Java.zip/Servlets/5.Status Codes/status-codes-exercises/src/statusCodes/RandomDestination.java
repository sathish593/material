package statusCodes;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class RandomDestination extends HttpServlet {
  public void doGet(HttpServletRequest request,
                    HttpServletResponse response)
      throws ServletException, IOException {
    if (Math.random() < 0.5) {
      response.sendRedirect("http://www.mozilla.org");
    } else {
      response.sendRedirect("http://www.microsoft.com");
    }
  }
}
