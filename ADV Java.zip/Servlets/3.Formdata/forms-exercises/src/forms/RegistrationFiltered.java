package forms;

import com.uhg.*;

/** The only differences between the Registration and RegistrationFiltered
 *  classes are the definition of the checkVal method (RegistrationFiltered
 *  added a call to the filter method).
 */

public class RegistrationFiltered extends Registration {

  /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

/** Returns error message if value is missing or is empty string.
   *  Filters the result otherwise.
   */

  protected String checkVal(String orig, String replacement) {
    if ((orig == null) || (orig.trim().equals(""))) {
      return("<FONT COLOR=RED><B>" + replacement + "</B></FONT>");
    } else {
      return(ServletUtilities.filter(orig));
    }
  }
}
